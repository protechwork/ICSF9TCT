create view vICS_GateEntryPList 
as
SELECT     TOP (100) PERCENT BookNo.iMasterId AS iBookNo,dbo.tCore_Data_0.iFaTag,tCore_Data_0.iInvTag,dbo.cCore_Vouchers_0.sAbbr,  dbo.tCore_Header_0.sVoucherNo as sVNo,dbo.cCore_Vouchers_0.sAbbr + ':' + dbo.tCore_Header_0.sVoucherNo AS sVoucherNo
                   FROM        dbo.tCore_Links_0 INNER JOIN
                  dbo.tCore_Data_0 ON dbo.tCore_Links_0.iTransactionId = dbo.tCore_Data_0.iTransactionId LEFT OUTER JOIN
                  dbo.tCore_Indta_0 ON dbo.tCore_Indta_0.iBodyId = dbo.tCore_Data_0.iBodyId INNER JOIN
                  dbo.tCore_Header_0 ON dbo.tCore_Data_0.iHeaderId = dbo.tCore_Header_0.iHeaderId INNER JOIN
                  dbo.cCore_Vouchers_0 WITH (READUNCOMMITTED) ON dbo.cCore_Vouchers_0.iVoucherType = dbo.tCore_Header_0.iVoucherType LEFT OUTER JOIN
                      (SELECT     iTransactionId, iUserId, SUM(Balance) AS Used
                       FROM        (SELECT DISTINCT a.iTransactionId, ISNULL(b.fValue, 0) AS Balance, a.iUserId
                                          FROM        (SELECT     dbo.tCore_Links_0.iRefId, dbo.tCore_Links_0.iTransactionId, dbo.tCore_Links_0.fValue, dbo.tCore_Links_0.iUserId
                                                             FROM        dbo.tCore_Links_0 INNER JOIN
                                                                               dbo.tCore_Data_0 ON dbo.tCore_Links_0.iTransactionId = dbo.tCore_Data_0.iTransactionId INNER JOIN
                                                                               dbo.tCore_Header_0 ON dbo.tCore_Data_0.iHeaderId = dbo.tCore_Header_0.iHeaderId
                                                             WHERE     (dbo.tCore_Links_0.bBase = 1) AND (dbo.tCore_Header_0.bSuspended = 0)) AS a LEFT OUTER JOIN
                                                                (SELECT     dbo.tCore_Links_0.iRefId, SUM(dbo.tCore_Links_0.fValue) AS fValue
                                                                 FROM        dbo.tCore_Links_0 INNER JOIN
                                                                                   dbo.tCore_Data_0 ON dbo.tCore_Links_0.iTransactionId = dbo.tCore_Data_0.iTransactionId INNER JOIN
                                                                                   dbo.tCore_Header_0 ON dbo.tCore_Data_0.iHeaderId = dbo.tCore_Header_0.iHeaderId
                                                                 WHERE     (dbo.tCore_Links_0.bBase = 0) AND (dbo.tCore_Header_0.bSuspended = 0) AND (dbo.tCore_Data_0.bSuspendLinkSaved = 0)
                                                                 GROUP BY dbo.tCore_Links_0.iRefId) AS b ON a.iRefId = b.iRefId) AS B
                       GROUP BY iTransactionId, iUserId) AS BaseTable ON BaseTable.iTransactionId = dbo.tCore_Data_0.iTransactionId LEFT OUTER JOIN
                      (SELECT     0 AS iTreeId, iMasterId, sName
                       FROM        dbo.mCore_Department
                       WHERE     (iStatus < 5)) AS vrCore_Department ON vrCore_Department.iMasterId = dbo.tCore_Data_0.iFaTag LEFT OUTER JOIN
                      (SELECT     0 AS iTreeId, iMasterId, sName
                       FROM        dbo.mCore_Account
                       WHERE     (iStatus < 5)) AS BookNo ON BookNo.iMasterId = dbo.tCore_Data_0.iBookNo LEFT OUTER JOIN
                      (SELECT     0 AS iTreeId, iMasterId, sName
                       FROM        dbo.mCore_Account
                       WHERE     (iStatus < 5)) AS Code ON Code.iMasterId = dbo.tCore_Data_0.iCode
WHERE     (dbo.tCore_Header_0.bSuspended = 0) AND (dbo.tCore_Data_0.iAuthStatus < 2) and (bBase != 1) 
GROUP BY dbo.tCore_Data_0.iBodyId, dbo.cCore_Vouchers_0.iVoucherType, dbo.cCore_Vouchers_0.sName, dbo.tCore_Header_0.iDate, dbo.cCore_Vouchers_0.sAbbr, vrCore_Department.iMasterId, BookNo.iMasterId, dbo.tCore_Header_0.sVoucherNo, dbo.tCore_Data_0.iFaTag,tCore_Data_0.iInvTag,
                  dbo.tCore_Links_0.iRefId, dbo.tCore_Links_0.bBase, dbo.tCore_Links_0.bClosed
ORDER BY dbo.tCore_Links_0.iRefId, dbo.tCore_Links_0.bBase DESC





































































































 










